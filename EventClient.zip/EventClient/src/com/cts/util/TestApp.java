package com.cts.util;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestApp {
	
	
	public static void main(String[] args) {
		 ClientConfig clientConfig = new DefaultClientConfig();
			Client client=Client.create(clientConfig);
			WebResource service = client.resource("http://localhost:9092/image/");
			ClientResponse cresponse = 
		    		service.path("rest").path("/imageservice/get/1;eventname=train")
		    		.type("text/plain")
		    	    .get(ClientResponse.class); 
		    System.out.println(cresponse);
		    System.out.println(cresponse.getCookies());
		    
	}

}
